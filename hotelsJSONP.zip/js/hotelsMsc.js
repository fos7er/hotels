_getHotelsMsc([
	{
		name: 'Kremlin Hotel',
		rating: 8.2,
		price: 1500,
		preview: 'img/9.jpeg'
	 },
	 {
		name: 'Barviha',
		rating: 8.7,
		price: 3500,
		preview: 'img/10.jpeg'
	 },
	 {
		name: 'Balashiha',
		rating: 6.9,
		price: 1100,
		preview: 'img/4.jpeg'
	 },
	  {
		name: 'Измайлово',
		rating: 7.5,
		price: 1600,
		preview: 'img/6.jpeg'
	 },
	  {
		name: 'Отель Звезда',
		rating: 7.2,
		price: 1350,
		preview: 'img/5.jpeg'
	 },
	  {
		name: 'Отель Волна',
		rating: 4.9,
		price: 500,
		preview: 'img/7.jpeg'
	 },
	  {
		name: 'Отель \"У Семёна\"',
		rating: 7.8,
		price: 1800,
		preview: 'img/9.jpeg'
	 },
	  {
		name: 'Отель Центральный',
		rating: 8.2,
		price: 1900,
		preview: 'img/3.jpeg'
	 }

	]);