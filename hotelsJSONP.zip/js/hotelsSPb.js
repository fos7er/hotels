_getHotelsSPb([
	{
		name: 'Palace Hote',
		rating: 8.2,
		price: 1400,
		preview: 'img/1.jpeg'
	 },
	 {
		name: 'Купчино',
		rating: 8.7,
		price: 3500,
		preview: 'img/2.jpeg'
	 },
	 {
		name: 'Отель Июнь',
		rating: 7.4,
		price: 1200,
		preview: 'img/3.jpeg'
	 },
	  {
		name: 'Отель Корона',
		rating: 4.5,
		price: 1600,
		preview: 'img/4.jpeg'
	 },
	  {
		name: 'Отель Дальний',
		rating: 6.2,
		price: 1350,
		preview: 'img/5.jpeg'
	 },
	  {
		name: 'The prancing pony',
		rating: 6.9,
		price: 999,
		preview: 'img/6.jpeg'
	 },
	  {
		name: 'Отель \"Дыбенко\"',
		rating: 7.8,
		price: 1800,
		preview: 'img/7.jpeg'
	 },
	  {
		name: 'Отель Центральный',
		rating: 8.2,
		price: 1750,
		preview: 'img/8.jpeg'
	 }

	]);
